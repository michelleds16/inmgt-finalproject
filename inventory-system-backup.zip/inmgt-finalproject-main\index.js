const express = require('express');
const mysql = require('mysql2');
const bodyParser = require('body-parser');
const path = require('path');
const session = require('express-session');
const app = express();

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(express.static('public'));

// Session Configuration
app.use(session({
    secret: 'inventory_secret_key',
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false } // Set to true if using https
}));

// Authentication Middleware
const requireAuth = (req, res, next) => {
    if (req.session.user) {
        // Make user available to all templates
        res.locals.user = req.session.user;
        res.locals.path = req.path;
        next();
    } else {
        res.redirect('/login');
    }
};

// Database Connection
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'inventory_db'
});

db.connect((err) => {
    if (err) {
        console.error('⚠️  Database connection error:', err.message);
        console.error('Please make sure:');
        console.error('  1. MySQL/XAMPP is running');
        console.error('  2. Database "inventory_db" exists');
        console.error('  3. Database credentials are correct');
        console.error('\nServer will still start, but database features may not work.\n');
    } else {
        console.log('✓ Connected to MySQL Database!');
    }
});

// ==================== AUTHENTICATION ====================

app.get('/login', (req, res) => {
    if (req.session.user) {
        return res.redirect('/');
    }
    res.render('login', { error: null });
});

app.post('/login', (req, res) => {
    const { username, password } = req.body;
    
    db.query('SELECT * FROM users WHERE username = ?', [username], (err, users) => {
        if (err) {
            console.error(err);
            return res.render('login', { error: 'System error' });
        }
        
        const user = users[0];
        
        if (user && user.password === password) { // Note: In production use bcrypt
            req.session.user = { 
                id: user.user_id,
                username: user.username, 
                role: user.role,
                fullname: user.fullname
            };
            res.redirect('/');
        } else {
            res.render('login', { error: 'Invalid username or password' });
        }
    });
});

app.get('/logout', (req, res) => {
    req.session.destroy((err) => {
        res.redirect('/login');
    });
});

// ==================== USER MANAGEMENT ====================

app.get('/users', requireAuth, (req, res) => {
    if (req.session.user.role !== 'Admin') {
        return res.redirect('/');
    }
    db.query('SELECT user_id, username, role, fullname, created_at FROM users', (err, users) => {
        if (err) throw err;
        res.render('users', { users: users });
    });
});

app.post('/api/users', requireAuth, (req, res) => {
    const { username, password, role, fullname } = req.body;
    db.query('INSERT INTO users (username, password, role, fullname) VALUES (?, ?, ?, ?)', 
        [username, password, role, fullname], (err) => {
        if (err) return res.json({ success: false, error: err.message });
        res.json({ success: true });
    });
});

app.delete('/api/users/:id', requireAuth, (req, res) => {
    if (req.session.user.role !== 'Admin') return res.json({ success: false, error: 'Unauthorized' });
    db.query('DELETE FROM users WHERE user_id = ?', [req.params.id], (err) => {
        if (err) return res.json({ success: false, error: err.message });
        res.json({ success: true });
    });
});

// ==================== SUPPLIER MANAGEMENT ====================

app.get('/suppliers', requireAuth, (req, res) => {
    db.query('SELECT * FROM suppliers ORDER BY supplier_name', (err, suppliers) => {
        if (err) throw err;
        res.render('suppliers', { suppliers: suppliers });
    });
});

app.post('/api/suppliers', requireAuth, (req, res) => {
    const { supplier_name, contact_person, email, phone, address } = req.body;
    db.query('INSERT INTO suppliers (supplier_name, contact_person, email, phone, address) VALUES (?, ?, ?, ?, ?)', 
        [supplier_name, contact_person, email, phone, address], (err) => {
        if (err) return res.json({ success: false, error: err.message });
        res.json({ success: true });
    });
});

app.delete('/api/suppliers/:id', requireAuth, (req, res) => {
    if (req.session.user.role !== 'Admin') return res.json({ success: false, error: 'Unauthorized' });
    db.query('DELETE FROM suppliers WHERE supplier_id = ?', [req.params.id], (err) => {
        if (err) return res.json({ success: false, error: err.message });
        res.json({ success: true });
    });
});

// ==================== REPORTS & POS ====================

app.get('/reports', requireAuth, (req, res) => {
    res.render('reports');
});

// Advanced Reports API
app.get('/api/reports/sales', requireAuth, (req, res) => {
    const { start_date, end_date } = req.query;
    let query = `
        SELECT DATE(t.transaction_date) as date, SUM(t.quantity * p.price) as revenue, COUNT(*) as count
        FROM transactions t
        JOIN products p ON t.product_id = p.product_id
        WHERE t.transaction_type = 'Sale'
    `;
    const params = [];
    if (start_date && end_date) {
        query += ' AND DATE(t.transaction_date) BETWEEN ? AND ?';
        params.push(start_date, end_date);
    }
    query += ' GROUP BY DATE(t.transaction_date) ORDER BY date';
    
    db.query(query, params, (err, results) => {
        if (err) throw err;
        res.json(results);
    });
});

// POS Page
app.get('/pos', requireAuth, (req, res) => {
    res.render('pos');
});

// POS Checkout
app.post('/api/pos/checkout', requireAuth, (req, res) => {
    const { items, total_amount } = req.body; // items: [{product_id, quantity, price}]
    const userId = req.session.user.id;
    const receiptId = 'RCPT-' + Date.now();

    if (!items || items.length === 0) {
        return res.json({ success: false, error: 'No items in cart' });
    }

    // Start transaction logic (simple version)
    // In production, use db.beginTransaction()
    
    let completed = 0;
    let errors = [];

    items.forEach(item => {
        // Check stock first
        db.query('SELECT stock_quantity FROM products WHERE product_id = ?', [item.product_id], (err, results) => {
            if (err || !results[0] || results[0].stock_quantity < item.quantity) {
                errors.push(`Insufficient stock for product ${item.product_id}`);
                checkDone();
                return;
            }

            // Deduct stock
            db.query('UPDATE products SET stock_quantity = stock_quantity - ? WHERE product_id = ?', [item.quantity, item.product_id], (err) => {
                if (err) {
                    errors.push(err.message);
                    checkDone();
                    return;
                }

                // Record transaction
                db.query('INSERT INTO transactions (product_id, user_id, transaction_type, quantity, receipt_id) VALUES (?, ?, "Sale", ?, ?)', 
                    [item.product_id, userId, item.quantity, receiptId], (err) => {
                    if (err) errors.push(err.message);
                    checkDone();
                });
            });
        });
    });

    function checkDone() {
        completed++;
        if (completed === items.length) {
            if (errors.length > 0) {
                res.json({ success: false, error: 'Some items failed: ' + errors.join(', ') });
            } else {
                res.json({ success: true, receipt_id: receiptId });
            }
        }
    }
});

// ==================== DASHBOARD & ANALYTICS ====================

// Main Dashboard Route
app.get('/', requireAuth, (req, res) => {
    const statsQuery = `
        SELECT 
            COALESCE((SELECT COUNT(*) FROM products), 0) AS total_products,
            COALESCE((SELECT SUM(quantity) FROM transactions WHERE transaction_type='Sale'), 0) AS total_sold,
            COALESCE((SELECT COUNT(*) FROM products WHERE stock_quantity < 10), 0) AS low_stock_alerts,
            COALESCE((SELECT SUM(t.quantity * p.price) FROM transactions t 
             JOIN products p ON t.product_id = p.product_id 
             WHERE t.transaction_type='Sale'), 0) AS total_revenue,
            COALESCE((SELECT COUNT(*) FROM transactions WHERE DATE(transaction_date) = CURDATE()), 0) AS today_transactions
    `;
    
    db.query(statsQuery, (err, stats) => {
        if (err) {
            console.error('Stats query error:', err);
            return res.render('dashboard', { 
                stats: { total_products: 0, total_sold: 0, low_stock_alerts: 0, total_revenue: 0, today_transactions: 0 },
                recentTransactions: [],
                salesData: [],
                topProducts: []
            });
        }
        
        // Ensure stats is properly initialized
        const statsData = stats && stats.length > 0 ? stats[0] : {
            total_products: 0,
            total_sold: 0,
            low_stock_alerts: 0,
            total_revenue: 0,
            today_transactions: 0
        };
        
        // Get recent transactions for activity feed
        const recentQuery = `
            SELECT t.*, p.product_name, p.price 
            FROM transactions t 
            LEFT JOIN products p ON t.product_id = p.product_id 
            ORDER BY t.transaction_date DESC 
            LIMIT 10
        `;
        
        db.query(recentQuery, (err, recentTransactions) => {
            if (err) {
                console.error('Recent transactions query error:', err);
                recentTransactions = [];
            }
            
            // Ensure it's an array
            if (!Array.isArray(recentTransactions)) {
                recentTransactions = [];
            }
            
            // Get sales data for last 7 days
            const salesQuery = `
                SELECT DATE(transaction_date) as date, 
                       COALESCE(SUM(quantity), 0) as quantity,
                       COALESCE(SUM(quantity * p.price), 0) as revenue
                FROM transactions t
                LEFT JOIN products p ON t.product_id = p.product_id
                WHERE transaction_type='Sale' 
                AND transaction_date >= DATE_SUB(NOW(), INTERVAL 7 DAY)
                GROUP BY DATE(transaction_date)
                ORDER BY date ASC
            `;
            
            db.query(salesQuery, (err, salesData) => {
                let safeSalesData = [];
                if (err) {
                    console.error('Sales data query error:', err);
                } else if (Array.isArray(salesData)) {
                    safeSalesData = salesData;
                }
                
                // Get top selling products
                const topProductsQuery = `
                    SELECT p.product_name, SUM(t.quantity) as total_sold, 
                           SUM(t.quantity * p.price) as revenue
                    FROM transactions t
                    LEFT JOIN products p ON t.product_id = p.product_id
                    WHERE t.transaction_type='Sale'
                    GROUP BY p.product_id
                    ORDER BY total_sold DESC
                    LIMIT 5
                `;
                
                db.query(topProductsQuery, (err, topProducts) => {
                    let safeTopProducts = [];
                    if (err) {
                        console.error('Top products query error:', err);
                    } else if (Array.isArray(topProducts)) {
                        safeTopProducts = topProducts;
                    }
                    
                    // Ensure all variables are defined
                    const safeRecentTransactions = Array.isArray(recentTransactions) ? recentTransactions : [];
                    
                    res.render('dashboard', { 
                        stats: statsData,
                        recentTransactions: safeRecentTransactions,
                        salesData: safeSalesData,
                        topProducts: safeTopProducts
                    });
                });
            });
        });
    });
});

// Analytics API Endpoint
app.get('/api/analytics', requireAuth, (req, res) => {
    const salesQuery = `
        SELECT DATE(transaction_date) as date, 
               SUM(quantity) as quantity,
               SUM(quantity * p.price) as revenue
        FROM transactions t
        JOIN products p ON t.product_id = p.product_id
        WHERE transaction_type='Sale' 
        AND transaction_date >= DATE_SUB(NOW(), INTERVAL 30 DAY)
        GROUP BY DATE(transaction_date)
        ORDER BY date ASC
    `;
    
    const categoryQuery = `
        SELECT p.category, 
               SUM(t.quantity) as quantity,
               SUM(t.quantity * p.price) as revenue
        FROM transactions t
        JOIN products p ON t.product_id = p.product_id
        WHERE t.transaction_type='Sale'
        GROUP BY p.category
    `;
    
    db.query(salesQuery, (err, salesData) => {
        if (err) throw err;
        
        db.query(categoryQuery, (err, categoryData) => {
            if (err) throw err;
            
            res.json({
                sales: salesData,
                categories: categoryData
            });
        });
    });
});

// ==================== BARCODE OPERATIONS ====================

// Scanner Page
app.get('/scanner', requireAuth, (req, res) => {
    res.render('scanner');
});

// Search product by barcode
app.get('/api/product/barcode/:barcode', requireAuth, (req, res) => {
    const barcode = req.params.barcode;
    db.query('SELECT * FROM products WHERE barcode = ?', [barcode], (err, results) => {
        if (err) throw err;
        res.json(results[0] || null);
    });
});

// Get all products (API)
app.get('/api/products', requireAuth, (req, res) => {
    db.query('SELECT * FROM products ORDER BY product_name', (err, products) => {
        if (err) throw err;
        res.json(products);
    });
});

// ==================== TRANSACTIONS ====================

// Handle Sale Transaction
app.post('/api/sell', requireAuth, (req, res) => {
    const { product_id, quantity, barcode } = req.body;
    
    // If barcode provided, find product first
    if (barcode && !product_id) {
        db.query('SELECT product_id FROM products WHERE barcode = ?', [barcode], (err, results) => {
            if (err || !results[0]) {
                return res.json({ success: false, error: 'Product not found' });
            }
            processSale(results[0].product_id, quantity, res);
        });
    } else if (product_id) {
        processSale(product_id, quantity, res);
    } else {
        res.json({ success: false, error: 'Product ID or Barcode required' });
    }
});

function processSale(productId, quantity, res) {
    // Check stock availability
    db.query('SELECT stock_quantity, product_name FROM products WHERE product_id = ?', [productId], (err, results) => {
        if (err) throw err;
        
        if (!results[0]) {
            return res.json({ success: false, error: 'Product not found' });
        }
        
        const currentStock = results[0].stock_quantity;
        const productName = results[0].product_name;
        
        if (currentStock < quantity) {
            return res.json({ success: false, error: `Insufficient stock. Available: ${currentStock}` });
        }
        
        // Record transaction
        db.query('INSERT INTO transactions (product_id, transaction_type, quantity) VALUES (?, "Sale", ?)', 
        [productId, quantity], (err) => {
            if (err) throw err;
            
            // Update stock
            db.query('UPDATE products SET stock_quantity = stock_quantity - ? WHERE product_id = ?', 
            [quantity, productId], (err) => {
                if (err) throw err;
                res.json({ success: true, message: `Sale recorded for ${productName}` });
            });
        });
    });
}

// Handle Purchase/Restock Transaction
app.post('/api/purchase', requireAuth, (req, res) => {
    const { product_id, quantity, barcode } = req.body;
    
    if (barcode && !product_id) {
        db.query('SELECT product_id FROM products WHERE barcode = ?', [barcode], (err, results) => {
            if (err || !results[0]) {
                return res.json({ success: false, error: 'Product not found' });
            }
            processPurchase(results[0].product_id, quantity, res);
        });
    } else if (product_id) {
        processPurchase(product_id, quantity, res);
    } else {
        res.json({ success: false, error: 'Product ID or Barcode required' });
    }
});

function processPurchase(productId, quantity, res) {
    db.query('INSERT INTO transactions (product_id, transaction_type, quantity) VALUES (?, "Purchase", ?)', 
    [productId, quantity], (err) => {
        if (err) throw err;
        
        db.query('UPDATE products SET stock_quantity = stock_quantity + ? WHERE product_id = ?', 
        [quantity, productId], (err) => {
            if (err) throw err;
            res.json({ success: true, message: 'Stock updated successfully' });
        });
    });
}

// Get all transactions
app.get('/api/transactions', requireAuth, (req, res) => {
    const query = `
        SELECT t.*, p.product_name, p.barcode, p.price, p.category
        FROM transactions t
        JOIN products p ON t.product_id = p.product_id
        ORDER BY t.transaction_date DESC
        LIMIT 100
    `;
    
    db.query(query, (err, transactions) => {
        if (err) throw err;
        res.json(transactions);
    });
});

// ==================== PRODUCT MANAGEMENT ====================

// Add New Product
app.post('/api/add-product', requireAuth, (req, res) => {
    const { product_name, barcode, category, price, stock_quantity, supplier_id, low_stock_threshold } = req.body;
    
    // Basic validation
    if (!product_name || !barcode || !price) {
        return res.json({ success: false, error: 'Missing required fields' });
    }

    const query = `
        INSERT INTO products 
        (product_name, barcode, category, price, stock_quantity, supplier_id, low_stock_threshold) 
        VALUES (?, ?, ?, ?, ?, ?, ?)
    `;
    
    db.query(query, 
        [product_name, barcode, category, price, stock_quantity, supplier_id || null, low_stock_threshold || 10], 
        (err) => {
        if (err) {
            if (err.code === 'ER_DUP_ENTRY') {
                return res.json({ success: false, error: 'Barcode already exists' });
            }
            return res.json({ success: false, error: err.message });
        }
        res.json({ success: true });
    });
});

// Update Product
app.put('/api/product/:id', requireAuth, (req, res) => {
    const { product_name, barcode, category, price, stock_quantity, supplier_id, low_stock_threshold } = req.body;
    
    const query = `
        UPDATE products 
        SET product_name=?, barcode=?, category=?, price=?, stock_quantity=?, supplier_id=?, low_stock_threshold=?
        WHERE product_id=?
    `;
    
    db.query(query, 
        [product_name, barcode, category, price, stock_quantity, supplier_id || null, low_stock_threshold || 10, req.params.id], 
        (err) => {
        if (err) return res.json({ success: false, error: err.message });
        res.json({ success: true });
    });
});

// Delete Product
app.delete('/api/product/:id', requireAuth, (req, res) => {
    const productId = req.params.id;
    
    db.query('DELETE FROM products WHERE product_id = ?', [productId], (err) => {
        if (err) throw err;
        res.json({ success: true, message: 'Product deleted successfully' });
    });
});

// ==================== INVENTORY MANAGEMENT ====================

// Get low stock products
app.get('/api/products/low-stock', requireAuth, (req, res) => {
    db.query('SELECT * FROM products WHERE stock_quantity < 10 ORDER BY stock_quantity ASC', (err, products) => {
        if (err) throw err;
        res.json(products);
    });
});

// ==================== INVENTORY & SCANNER ====================

app.get('/inventory', requireAuth, (req, res) => {
    db.query(`
        SELECT p.*, s.supplier_name 
        FROM products p 
        LEFT JOIN suppliers s ON p.supplier_id = s.supplier_id 
        ORDER BY p.product_name`, (err, products) => {
        if (err) throw err;
        res.render('inventory', { products: products });
    });
});

app.get('/scanner', requireAuth, (req, res) => {
    res.render('scanner');
});

// ==================== SALES MONITORING ====================

// Sales Monitoring Page
app.get('/sales', requireAuth, (req, res) => {
    const query = `
        SELECT t.*, p.product_name, p.barcode, p.price, p.category, u.username,
               (t.quantity * p.price) as total_amount
        FROM transactions t
        JOIN products p ON t.product_id = p.product_id
        LEFT JOIN users u ON t.user_id = u.user_id
        WHERE t.transaction_type='Sale'
        ORDER BY t.transaction_date DESC
        LIMIT 100
    `;
    
    db.query(query, (err, sales) => {
        if (err) throw err;
        
        // Calculate summary
        const summaryQuery = `
            SELECT 
                COUNT(*) as total_sales,
                SUM(t.quantity) as total_items_sold,
                SUM(t.quantity * p.price) as total_revenue,
                AVG(t.quantity * p.price) as avg_sale_amount
            FROM transactions t
            JOIN products p ON t.product_id = p.product_id
            WHERE t.transaction_type='Sale'
        `;
        
        db.query(summaryQuery, (err, summary) => {
            if (err) throw err;
            res.render('sales', { sales: sales, summary: summary[0] });
        });
    });
});

// Products Management Page
app.get('/products', requireAuth, (req, res) => {
    db.query(`
        SELECT p.*, s.supplier_name 
        FROM products p 
        LEFT JOIN suppliers s ON p.supplier_id = s.supplier_id 
        ORDER BY p.product_name`, (err, products) => {
        if (err) throw err;
        
        // Also get suppliers for the add/edit modal
        db.query('SELECT * FROM suppliers ORDER BY supplier_name', (err, suppliers) => {
            if (err) throw err;
            res.render('products', { products: products, suppliers: suppliers });
        });
    });
});

const PORT = 3000;
app.listen(PORT, () => {
    console.log('='.repeat(50));
    console.log(`🚀 Server started at http://localhost:${PORT}`);
    console.log('='.repeat(50));
});
