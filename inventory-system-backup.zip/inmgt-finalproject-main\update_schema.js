const mysql = require('mysql2');

const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'inventory_db',
    multipleStatements: true
});

const schemaUpdates = `
    -- Create Users Table
    CREATE TABLE IF NOT EXISTS users (
        user_id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(50) UNIQUE NOT NULL,
        password VARCHAR(255) NOT NULL,
        role VARCHAR(20) NOT NULL DEFAULT 'Staff', -- Admin, Staff
        fullname VARCHAR(100),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );

    -- Create Suppliers Table
    CREATE TABLE IF NOT EXISTS suppliers (
        supplier_id INT AUTO_INCREMENT PRIMARY KEY,
        supplier_name VARCHAR(100) NOT NULL,
        contact_person VARCHAR(100),
        email VARCHAR(100),
        phone VARCHAR(20),
        address TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );

    -- Update Products Table (Add Supplier Link)
    -- We'll use a procedure to safely add columns if they don't exist
    DROP PROCEDURE IF EXISTS upgrade_products;
    DELIMITER //
    CREATE PROCEDURE upgrade_products()
    BEGIN
        IF NOT EXISTS (SELECT * FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = 'inventory_db' AND TABLE_NAME = 'products' AND COLUMN_NAME = 'supplier_id') THEN
            ALTER TABLE products ADD COLUMN supplier_id INT;
            ALTER TABLE products ADD FOREIGN KEY (supplier_id) REFERENCES suppliers(supplier_id) ON DELETE SET NULL;
        END IF;
    END //
    DELIMITER ;
    CALL upgrade_products();
    DROP PROCEDURE upgrade_products;

    -- Update Transactions Table (Add User Link and Receipt ID)
    DROP PROCEDURE IF EXISTS upgrade_transactions;
    DELIMITER //
    CREATE PROCEDURE upgrade_transactions()
    BEGIN
        IF NOT EXISTS (SELECT * FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = 'inventory_db' AND TABLE_NAME = 'transactions' AND COLUMN_NAME = 'user_id') THEN
            ALTER TABLE transactions ADD COLUMN user_id INT;
            ALTER TABLE transactions ADD FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE SET NULL;
        END IF;
        
        IF NOT EXISTS (SELECT * FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = 'inventory_db' AND TABLE_NAME = 'transactions' AND COLUMN_NAME = 'receipt_id') THEN
            ALTER TABLE transactions ADD COLUMN receipt_id VARCHAR(50);
        END IF;
    END //
    DELIMITER ;
    CALL upgrade_transactions();
    DROP PROCEDURE upgrade_transactions;

    -- Seed Default Admin User (if not exists)
    INSERT IGNORE INTO users (username, password, role, fullname) VALUES 
    ('admin', 'admin123', 'Admin', 'System Administrator'),
    ('staff', 'staff123', 'Staff', 'Sales Staff');

    -- Seed Sample Suppliers
    INSERT INTO suppliers (supplier_name, contact_person, email, phone, address) 
    SELECT * FROM (SELECT 'TechDistributors Inc.', 'John Doe', 'john@techdist.com', '0917-123-4567', 'Manila, Philippines') AS tmp
    WHERE NOT EXISTS (SELECT name FROM (SELECT supplier_name as name FROM suppliers) s WHERE name = 'TechDistributors Inc.') LIMIT 1;

    INSERT INTO suppliers (supplier_name, contact_person, email, phone, address)
    SELECT * FROM (SELECT 'Office Depot Supplies', 'Jane Smith', 'jane@officesupplies.com', '0918-987-6543', 'Quezon City, Philippines') AS tmp
    WHERE NOT EXISTS (SELECT name FROM (SELECT supplier_name as name FROM suppliers) s WHERE name = 'Office Depot Supplies') LIMIT 1;
`;

db.connect((err) => {
    if (err) {
        console.error('Connection failed:', err);
        return;
    }
    console.log('Connected to database. Running schema updates...');

    // We need to split statements because mysql2 query with multipleStatements: true 
    // might choke on DELIMITER syntax which is client-side.
    // Instead, I'll run standard queries. DELIMITER is not needed for single statements or if I avoid procedures.
    // Let's rewrite without procedures for simplicity in node.
    
    const queries = [
        `CREATE TABLE IF NOT EXISTS users (
            user_id INT AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(50) UNIQUE NOT NULL,
            password VARCHAR(255) NOT NULL,
            role VARCHAR(20) NOT NULL DEFAULT 'Staff',
            fullname VARCHAR(100),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )`,
        
        `CREATE TABLE IF NOT EXISTS suppliers (
            supplier_id INT AUTO_INCREMENT PRIMARY KEY,
            supplier_name VARCHAR(100) NOT NULL,
            contact_person VARCHAR(100),
            email VARCHAR(100),
            phone VARCHAR(20),
            address TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )`,

        // Direct ALTERs might fail if column exists, so we wrap in a try-catch block in logic or use a specific query pattern
        // For simplicity in this env, we can try to add and ignore error if it says "Duplicate column"
        // But cleaner is to check first.
        
        `SET @dbname = DATABASE()`,
        
        `SET @exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = @dbname AND TABLE_NAME = 'products' AND COLUMN_NAME = 'supplier_id')`,
        `SET @sql := IF(@exist = 0, 'ALTER TABLE products ADD COLUMN supplier_id INT, ADD FOREIGN KEY (supplier_id) REFERENCES suppliers(supplier_id) ON DELETE SET NULL', 'SELECT 1')`,
        `PREPARE stmt FROM @sql`,
        `EXECUTE stmt`,
        `DEALLOCATE PREPARE stmt`,

        `SET @exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = @dbname AND TABLE_NAME = 'transactions' AND COLUMN_NAME = 'user_id')`,
        `SET @sql := IF(@exist = 0, 'ALTER TABLE transactions ADD COLUMN user_id INT, ADD FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE SET NULL', 'SELECT 1')`,
        `PREPARE stmt FROM @sql`,
        `EXECUTE stmt`,
        `DEALLOCATE PREPARE stmt`,

        `SET @exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = @dbname AND TABLE_NAME = 'transactions' AND COLUMN_NAME = 'receipt_id')`,
        `SET @sql := IF(@exist = 0, 'ALTER TABLE transactions ADD COLUMN receipt_id VARCHAR(50)', 'SELECT 1')`,
        `PREPARE stmt FROM @sql`,
        `EXECUTE stmt`,
        `DEALLOCATE PREPARE stmt`,
        
        `INSERT IGNORE INTO users (username, password, role, fullname) VALUES 
         ('admin', 'admin123', 'Admin', 'System Administrator'),
         ('staff', 'staff123', 'Staff', 'Sales Staff')`,
         
        `INSERT IGNORE INTO suppliers (supplier_name, contact_person, email, phone, address) VALUES
         ('TechDistributors Inc.', 'John Doe', 'john@techdist.com', '0917-123-4567', 'Manila, Philippines'),
         ('Office Depot Supplies', 'Jane Smith', 'jane@officesupplies.com', '0918-987-6543', 'Quezon City, Philippines')`
    ];

    executeQueries(queries, 0);
});

function executeQueries(queries, index) {
    if (index >= queries.length) {
        console.log('✓ Database schema updated successfully!');
        process.exit(0);
        return;
    }

    db.query(queries[index], (err) => {
        if (err) {
            console.error('Error executing query:', queries[index]);
            console.error(err);
            process.exit(1);
        }
        executeQueries(queries, index + 1);
    });
}
