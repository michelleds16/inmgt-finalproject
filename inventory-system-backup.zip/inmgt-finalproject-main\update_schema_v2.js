const mysql = require('mysql2');

const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'inventory_db'
});

db.connect((err) => {
    if (err) throw err;
    console.log('Connected to database');

    const queries = [
        `CREATE TABLE IF NOT EXISTS suppliers (
            supplier_id INT AUTO_INCREMENT PRIMARY KEY,
            supplier_name VARCHAR(255) NOT NULL,
            contact_person VARCHAR(255),
            email VARCHAR(255),
            phone VARCHAR(50),
            address TEXT
        )`,
        `ALTER TABLE products ADD COLUMN IF NOT EXISTS supplier_id INT`,
        `ALTER TABLE products ADD CONSTRAINT fk_supplier FOREIGN KEY (supplier_id) REFERENCES suppliers(supplier_id) ON DELETE SET NULL`,
        `ALTER TABLE products ADD COLUMN IF NOT EXISTS low_stock_threshold INT DEFAULT 10`
    ];

    let completed = 0;
    queries.forEach(query => {
        db.query(query, (err) => {
            // Ignore errors like "Duplicate column name" or "Constraint already exists"
            if (err && err.code !== 'ER_DUP_FIELDNAME' && err.code !== 'ER_DUP_KEYNAME') {
                console.error('Query error:', err.message);
            }
            completed++;
            if (completed === queries.length) {
                console.log('Schema update completed');
                process.exit();
            }
        });
    });
});
