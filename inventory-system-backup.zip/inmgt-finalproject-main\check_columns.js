const mysql = require('mysql2');

const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'inventory_db'
});

db.connect((err) => {
    if (err) {
        console.error(err);
        process.exit(1);
    }
    
    db.query('DESCRIBE products', (err, results) => {
        if (err) {
            console.error(err);
        } else {
            console.log('Products table columns:');
            results.forEach(col => console.log(`- ${col.Field} (${col.Type})`));
        }
        process.exit();
    });
});
