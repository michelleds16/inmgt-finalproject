Write-Host "Starting Inventory Management Server..." -ForegroundColor Green
Write-Host ""
Set-Location $PSScriptRoot
node index.js

