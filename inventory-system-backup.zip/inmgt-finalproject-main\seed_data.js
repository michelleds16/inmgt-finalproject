const mysql = require('mysql2');

const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'inventory_db',
    multipleStatements: true
});

const products = [
    // Electronics
    { name: 'Wireless Mouse', barcode: '2234567890124', category: 'Electronics', price: 599.00, stock: 45 },
    { name: 'Gaming Keyboard', barcode: '1234567890123', category: 'Electronics', price: 2499.00, stock: 15 },
    { name: '24" IPS Monitor', barcode: '6234567890128', category: 'Electronics', price: 8500.00, stock: 8 },
    { name: 'USB-C Hub', barcode: '8834567890129', category: 'Electronics', price: 1200.00, stock: 30 },
    { name: 'Bluetooth Speaker', barcode: '9934567890130', category: 'Electronics', price: 1800.00, stock: 25 },
    { name: 'Webcam 1080p', barcode: '7734567890131', category: 'Electronics', price: 1500.00, stock: 12 },
    
    // Groceries / Snacks
    { name: 'Potato Chips', barcode: '5550001112223', category: 'Groceries', price: 45.00, stock: 100 },
    { name: 'Energy Drink', barcode: '5550001112224', category: 'Groceries', price: 85.00, stock: 150 },
    { name: 'Chocolate Bar', barcode: '5550001112225', category: 'Groceries', price: 35.00, stock: 200 },
    { name: 'Instant Coffee', barcode: '5550001112226', category: 'Groceries', price: 250.00, stock: 60 },
    
    // Office Supplies
    { name: 'A4 Paper Ream', barcode: '4440001112227', category: 'Office', price: 220.00, stock: 50 },
    { name: 'Ballpoint Pen (Box)', barcode: '4440001112228', category: 'Office', price: 150.00, stock: 80 },
    { name: 'Stapler', barcode: '4440001112229', category: 'Office', price: 180.00, stock: 40 },
    
    // Clothing
    { name: 'Cotton T-Shirt', barcode: '3330001112230', category: 'Clothing', price: 350.00, stock: 75 },
    { name: 'Denim Jeans', barcode: '3330001112231', category: 'Clothing', price: 1200.00, stock: 30 },
    { name: 'Running Socks', barcode: '3330001112232', category: 'Clothing', price: 150.00, stock: 60 }
];

db.connect(async (err) => {
    if (err) {
        console.error('Connection failed:', err);
        return;
    }
    console.log('Connected to database. Starting seed...');

    try {
        // Clear existing data
        await promiseQuery('SET FOREIGN_KEY_CHECKS = 0');
        await promiseQuery('TRUNCATE TABLE transactions');
        await promiseQuery('TRUNCATE TABLE products');
        await promiseQuery('SET FOREIGN_KEY_CHECKS = 1');
        console.log('✓ Tables cleared');

        // Insert Products
        const productIds = [];
        for (const p of products) {
            const result = await promiseQuery(
                'INSERT INTO products (product_name, barcode, category, price, stock_quantity) VALUES (?, ?, ?, ?, ?)',
                [p.name, p.barcode, p.category, p.price, p.stock]
            );
            productIds.push(result.insertId);
        }
        console.log(`✓ Inserted ${products.length} products`);

        // Generate Transactions
        // Create sales distributed over last 30 days
        const transactionCount = 100;
        let insertedTransactions = 0;

        for (let i = 0; i < transactionCount; i++) {
            const randomProductIndex = Math.floor(Math.random() * productIds.length);
            const productId = productIds[randomProductIndex];
            const product = products[randomProductIndex];
            
            // Random date within last 30 days
            const daysAgo = Math.floor(Math.random() * 30);
            const date = new Date();
            date.setDate(date.getDate() - daysAgo);
            
            // Random quantity 1-5
            const quantity = Math.floor(Math.random() * 5) + 1;
            
            // 80% Sales, 20% Purchases
            const type = Math.random() > 0.2 ? 'Sale' : 'Purchase';
            
            await promiseQuery(
                'INSERT INTO transactions (product_id, transaction_type, quantity, transaction_date) VALUES (?, ?, ?, ?)',
                [productId, type, quantity, date]
            );
            insertedTransactions++;
        }
        console.log(`✓ Inserted ${insertedTransactions} transactions`);
        
        console.log('\nSeed completed successfully! You can now login.');
        process.exit(0);

    } catch (error) {
        console.error('Seeding error:', error);
        process.exit(1);
    }
});

function promiseQuery(sql, args) {
    return new Promise((resolve, reject) => {
        db.query(sql, args, (err, rows) => {
            if (err) return reject(err);
            resolve(rows);
        });
    });
}
