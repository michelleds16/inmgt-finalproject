-- Create Database
CREATE DATABASE IF NOT EXISTS inventory_db;
USE inventory_db;

-- Create Products Table
CREATE TABLE IF NOT EXISTS products (
    product_id INT AUTO_INCREMENT PRIMARY KEY,
    product_name VARCHAR(255) NOT NULL,
    barcode VARCHAR(100) UNIQUE NOT NULL,
    category VARCHAR(100),
    price DECIMAL(10, 2) NOT NULL,
    stock_quantity INT NOT NULL DEFAULT 0
);

-- Create Transactions Table
CREATE TABLE IF NOT EXISTS transactions (
    transaction_id INT AUTO_INCREMENT PRIMARY KEY,
    product_id INT NOT NULL,
    transaction_type VARCHAR(50) NOT NULL, -- 'Sale' or 'Purchase'
    quantity INT NOT NULL,
    transaction_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (product_id) REFERENCES products(product_id) ON DELETE CASCADE
);

-- Insert Sample Data (Optional)
INSERT INTO products (product_name, barcode, category, price, stock_quantity) VALUES
('Wireless Mouse', 'WM001', 'Electronics', 25.99, 50),
('Mechanical Keyboard', 'MK002', 'Electronics', 89.99, 20),
('USB-C Cable', 'UC003', 'Accessories', 12.50, 100),
('Laptop Stand', 'LS004', 'Accessories', 45.00, 15),
('Monitor 24"', 'MN005', 'Electronics', 150.00, 10);

-- Insert Sample Transactions
INSERT INTO transactions (product_id, transaction_type, quantity, transaction_date) VALUES
(1, 'Purchase', 50, DATE_SUB(NOW(), INTERVAL 5 DAY)),
(1, 'Sale', 2, DATE_SUB(NOW(), INTERVAL 4 DAY)),
(2, 'Purchase', 20, DATE_SUB(NOW(), INTERVAL 3 DAY)),
(3, 'Purchase', 100, DATE_SUB(NOW(), INTERVAL 2 DAY)),
(3, 'Sale', 5, DATE_SUB(NOW(), INTERVAL 1 DAY));
